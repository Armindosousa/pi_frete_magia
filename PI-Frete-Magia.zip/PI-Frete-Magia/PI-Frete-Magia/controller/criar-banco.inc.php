<?php
 $sql = "CREATE DATABASE IF NOT EXISTS $freteMagia";
 $conexao->query($sql) or exit($conexao->error);