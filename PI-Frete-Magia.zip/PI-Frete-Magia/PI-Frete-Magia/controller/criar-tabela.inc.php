<?php
 //Neste include, cria-se uma tabela no modelo:
 $sql = "CREATE TABLE IF NOT EXISTS $passageiro(
          id VARCHAR(20) PRIMARY KEY,
          nome varchar(50) not null,
          cpf varchar(11),
          telefone varchar(15),
          endereco varchar(100),
          email varchar(20),
          senha varchar(20)";

 $conexao->query($sql) or exit($conexao->error);

 $sql = "CREATE TABLE IF NOT EXISTS $Motorista(
    id VARCHAR(20) PRIMARY KEY,
    nome varchar(50) not null,
    cpf varchar(11),
    telefone varchar(15),
    endereco varchar(100),
    cnh varchar(11),
    email varchar(20),
    senha varchar(20)";

$conexao->query($sql) or exit($conexao->error);