<?php
 $conexao->select_db($freteMagia);