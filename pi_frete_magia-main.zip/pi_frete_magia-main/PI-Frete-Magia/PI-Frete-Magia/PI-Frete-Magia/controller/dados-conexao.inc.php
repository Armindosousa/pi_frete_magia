<?php
 $servidor      = "localhost";
 $usuario       = "root";
 $senha         = "";

 //conexão da tabela passageiro
 $nomeDoBanco   = "freteMagia";
 $nomeDaTabela1  = "passageiro";
 $nomeDaTabela2  = "empresa";
 $nomeDaTabela3  = "motorista";

 
 