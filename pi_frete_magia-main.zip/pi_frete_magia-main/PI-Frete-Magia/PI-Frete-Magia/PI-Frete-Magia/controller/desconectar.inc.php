<?php
 //este comando é chamado toda vez que encerramos nossa aplicação e desejamos que o PHP corte a conexão com o banco de dados
 $conexao->close();