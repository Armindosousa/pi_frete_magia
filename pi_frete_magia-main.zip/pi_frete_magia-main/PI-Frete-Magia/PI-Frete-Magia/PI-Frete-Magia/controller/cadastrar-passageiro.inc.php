<?php

 /*$id =  $_POST['id'];
 $orcamento =  $_POST['orcamento']; 
 $dataInicio =  $_POST['data-inicio'];
 $horasExecucao =  $_POST['horas-execucao'];*/

$idPassageiro = $conexao->escape_string(trim($_POST["id"]));

$nomePassageiro = $conexao->escape_string(trim($_POST["Nome-Completo"]));

$cpfPassageiro = $conexao->escape_string(trim($_POST["CPF"]));

$telefonePassageiro = $conexao->escape_string(trim($_POST["Telefone"]));

$enderecoPassageiro = $conexao->escape_string(trim($_POST["Endereco"]));

$emailPassageiro = $conexao->escape_string(trim($_POST["Email"]));

$senhaPassageiro = $conexao->escape_string(trim($_POST["Senha"]));


 $sql = " INSERT $passageiro VALUES( 
                 '$nomePassageiro', 
                 '$cpfPassageiro',
                 '$telefonePassageiro',
                 '$enderecoPassageiro',
                 '$emailPassageiro',
                 '$senhaPassageiro')";

 $conexao->query($sql) or die($conexao->error);
 
 echo "<p> Passageiro cadastrado com sucesso! </p>";

