<?php
 $conexao->set_charset("utf8");