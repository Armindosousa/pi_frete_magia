<?php
 $servidor      = "localhost";
 $usuario       = "root";
 $senha         = "";

 //conexão da tabela passageiro
 $nomeDoBanco   = "freteMagia";
 $tabelaPassageiro  = "passageiro";
 $tabelaEmpresa  = "empresa";
 $tabelaMotorista  = "motorista";

 
 