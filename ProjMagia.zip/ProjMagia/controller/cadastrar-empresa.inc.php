<?php

 /*$id =  $_POST['id'];
 $orcamento =  $_POST['orcamento']; 
 $dataInicio =  $_POST['data-inicio'];
 $horasExecucao =  $_POST['horas-execucao'];*/


$RazaoSocial = $conexao->escape_string(trim($_POST["razão-social"]));

$CnpjEmpresa = $conexao->escape_string(trim($_POST["cnpj-empresa"]));

$NomeEmpresa = $conexao->escape_string(trim($_POST["nome-empresa"]));

$DataFundacao = $conexao->escape_string(trim($_POST["data_fundacao"]));

$EnderecoEmpresa = $conexao->escape_string(trim($_POST["endereco-empresa"]));

$EmailEmpresa = $conexao->escape_string(trim($_POST["email-empresa"]));

$TelefoneEmpresa = $conexao->escape_string(trim($_POST["telefone-empresa"]));

$SenhaEmpresa = $conexao->escape_string(trim($_POST["senha-empresa"]));


 $sql = " INSERT INTO $tabelaEmpresa VALUES( 
                 '$RazaoSocial', 
                 '$CnpjEmpresa',
                 '$NomeEmpresa',
                 '$DataFundacao',
                 '$EnderecoEmpresa',
                 '$EmailEmpresa',
                 '$TelefoneEmpresa',
                 '$SenhaEmpresa')";

 $conexao->query($sql) or die($conexao->error);
 
 echo "<p> Empresa cadastrado com sucesso! </p>";

 
   
