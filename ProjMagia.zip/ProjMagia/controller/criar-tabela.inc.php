<?php
 //Neste include, cria-se uma tabela do Passageiro:
 $sql = "CREATE TABLE IF NOT EXISTS $tabelaPassageiro(
          id int PRIMARY KEY AUTO_INCREMENT,
          nome varchar(50) not null,
          cpf varchar(11),
          telefone varchar(15),
          endereco varchar(100),
          email varchar(20),
          senha varchar(20))";

 $conexao->query($sql) or exit($conexao->error);

//Tabela da empresa
$sql = "CREATE TABLE IF NOT EXISTS $tabelaEmpresa(
    id int PRIMARY KEY AUTO_INCREMENT,
    razão-social varchar(50) not null,
    cnpj-empresa varchar(15),
    nome-empresa varchar(50),
    data_fundacao date,
    endereco-empresa varchar(100),
    email-empresa varchar(100),
    telefone-empresa varchar(15),
    senha-empresa varchar(20))";

$conexao->query($sql) or exit($conexao->error);


//Tabela de Motorista
 $sql = "CREATE TABLE IF NOT EXISTS $tabelaMotorista(
    id int PRIMARY KEY AUTO_INCREMENT,
    nome varchar(50) not null,
    cpf varchar(11),
    telefone varchar(15),
    endereco varchar(100),
    cnh varchar(11),
    email varchar(20),
    senha varchar(20))";

$conexao->query($sql) or exit($conexao->error);

