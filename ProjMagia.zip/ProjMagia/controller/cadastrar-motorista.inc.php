<?php

 /*$id =  $_POST['id'];
 $orcamento =  $_POST['orcamento']; 
 $dataInicio =  $_POST['data-inicio'];
 $horasExecucao =  $_POST['horas-execucao'];*/

$nomeMotorista = $conexao->escape_string(trim($_POST["Nome-Completo"]));

$cpfMotorista = $conexao->escape_string(trim($_POST["CPF"]));

$telefoneMotorista = $conexao->escape_string(trim($_POST["Telefone"]));

$enderecoMotorista = $conexao->escape_string(trim($_POST["Endereco"]));

$cnhMotorista = $conexao->escape_string(trim($_POST["CNH"]));

$emailMotorista = $conexao->escape_string(trim($_POST["Email"]));

$senhaMotorista = $conexao->escape_string(trim($_POST["Senha"]));


 $sql = " INSERT $tabelaMotorista VALUES(
                 '$nomeMotorista', 
                 '$cpfMotorista',
                 '$telefoneMotorista',
                 '$enderecoMotorista',
                 '$cnhMotorista',
                 '$emailMotorista',
                 '$senhaPassageiro')";

 $conexao->query($sql) or die($conexao->error);
 
 echo "<p> Motorista cadastrado com sucesso! </p>";

